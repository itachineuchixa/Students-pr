﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Studentspr
{
    /// <summary>
    /// Логика взаимодействия для student_page.xaml
    /// </summary>
    public partial class student_page : Page
    {
        public student_page()
        {
            InitializeComponent();
            DGridHotels.ItemsSource = StudentsEntities.GetContext().Students.ToList();
            CmbFiltrLogin.ItemsSource = StudentsEntities.GetContext().Groups.ToList();
            CmbFiltrLogin.SelectedValuePath = "Id";
            CmbFiltrLogin.DisplayMemberPath = "group_name";
        }

        private void CmbFiltrLogin_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrLogin.SelectedValue);
            DGridHotels.ItemsSource = StudentsEntities.GetContext().Students.Where(x => x.Id == id).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            //сброс фильтрации
            DGridHotels.ItemsSource = StudentsEntities.GetContext().Students.ToList();
        }

        private void BtnExcelAll_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexrows = 1;
            worksheet.Cells[1][indexrows] = "ФИО";
            worksheet.Cells[2][indexrows] = "Возраст";
            worksheet.Cells[3][indexrows] = "Группа";
            worksheet.Cells[4][indexrows] = "Пол";
            worksheet.Cells[5][indexrows] = "Номер зачетки";
            var printItems = StudentsEntities.GetContext().Students.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexrows + 1] = item.FIO;
                worksheet.Cells[2][indexrows + 1] = item.age;
                worksheet.Cells[3][indexrows + 1] = item.Groups.group_name;
                worksheet.Cells[4][indexrows + 1] = item.gender;
                worksheet.Cells[5][indexrows + 1] = item.n_zachetki;
                indexrows++;
            }
            app.Visible = true;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Add_student_page((sender as Button).DataContext as Students));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Add_student_page(null));
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Main_menu());
        }

        private void RadioButton_Click(object sender, RoutedEventArgs e)
        {
            if (rad.IsChecked == true)
            {
                List<Marks> Mark = StudentsEntities.GetContext().Marks.ToList();
                List<int> users = new List<int>();
                var marks = from mark in Mark group mark by mark.students_id;
                foreach(var mark in marks)
                {
                    List<int> cenki = new List<int>();
                    int user = 0;
                    foreach(var mar in mark)
                    {
                        cenki.Add(mar.Mark);
                        user = mar.students_id;
                    }
                    if (cenki.Average() == 5) users.Add(user);
                }
                DGridHotels.ItemsSource = from st in StudentsEntities.GetContext().Students.ToList() where users.Contains(st.Id) select st;
            }
            else DGridHotels.ItemsSource = StudentsEntities.GetContext().Students.ToList();
        }
    }
}
