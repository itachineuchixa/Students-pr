﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Studentspr
{
    /// <summary>
    /// Логика взаимодействия для mark_page.xaml
    /// </summary>
    public partial class mark_page : Page
    {
        private List<Marks> _currentdata;
        public mark_page()
        {
            InitializeComponent();
            _currentdata = StudentsEntities.GetContext().Marks.ToList();
            DGridHotels.ItemsSource = _currentdata;
            CmbFiltrLogin.ItemsSource = StudentsEntities.GetContext().Students.ToList();
            CmbFiltrLogin.SelectedValuePath = "Id";
            CmbFiltrLogin.DisplayMemberPath = "FIO";
        }
        private void CmbFiltrLogin_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrLogin.SelectedValue);
            _currentdata = StudentsEntities.GetContext().Marks.Where(x => x.students_id == id).ToList();
            DGridHotels.ItemsSource = _currentdata;
            
        }
        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            //сброс фильтрации
            _currentdata = StudentsEntities.GetContext().Marks.ToList();
            DGridHotels.ItemsSource = _currentdata;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnExcelAll_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexrows = 2;
            worksheet.Cells[2][1] = "Сводная ведомость";
            worksheet.Cells[1][2] = "Студент";
            worksheet.Cells[2][2] = "Предмет";
            worksheet.Cells[3][2] = "Оценка";
            var printItems = _currentdata;
            string curr_student = "";
            foreach (var item in printItems)
            {
                if (curr_student != item.Students.FIO)
                {
                    worksheet.Cells[1][indexrows + 1] = item.Students.FIO;
                    curr_student = item.Students.FIO;
                };
                worksheet.Cells[2][indexrows + 1] = item.Subjects.subject;
                worksheet.Cells[3][indexrows + 1] = item.Mark;
                indexrows++;
            }

            worksheet.get_Range("A2", "C" + indexrows.ToString()).Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            worksheet.Cells[2][indexrows +2] = "Дата:";
            worksheet.Cells[3][indexrows + 2] = DateTime.Now;
            worksheet.Cells[2][indexrows + 3] = "Подпись:";
            worksheet.Cells[3][indexrows + 3] = DateTime.Now;
            worksheet.Columns.AutoFit();
            app.Visible = true;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Add_mark_page((sender as Button).DataContext as Marks));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {// удаление нескольких пользователей
            var usersForRemoving = DGridHotels.SelectedItems.Cast<Marks>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} предмеов?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    StudentsEntities.GetContext().Marks.RemoveRange(usersForRemoving);
                    StudentsEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridHotels.ItemsSource = StudentsEntities.GetContext().Marks.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }


        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Add_mark_page(null));
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Main_menu());
        }
    }
}
