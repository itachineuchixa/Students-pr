﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Studentspr
{
    /// <summary>
    /// Логика взаимодействия для Add_special_page.xaml
    /// </summary>
    public partial class Add_special_page : Page
    {
        private Specials _currentspecial = new Specials();
        public Add_special_page(Specials selectedSpecial)
        {
            InitializeComponent();
            if (selectedSpecial != null) _currentspecial = selectedSpecial;

            DataContext = _currentspecial;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentspecial.Special))
                errors.AppendLine("Укажите названия группы");
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            if (_currentspecial.Id == 0)
                StudentsEntities.GetContext().Specials.Add(_currentspecial);
            try
            {
                StudentsEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена!");
                manager.MainFrame.Navigate(new special_page());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new special_page());
        }
    }
}
