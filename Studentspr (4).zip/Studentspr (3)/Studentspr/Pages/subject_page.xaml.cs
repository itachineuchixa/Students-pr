﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
namespace Studentspr
{
    /// <summary>
    /// Логика взаимодействия для subject_page.xaml
    /// </summary>
    public partial class subject_page : Page
    {
        public subject_page()
        {
            InitializeComponent();
            DGridHotels.ItemsSource = StudentsEntities.GetContext().Subjects.ToList();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnExcelAll_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexrows = 1;
            worksheet.Cells[1][indexrows] = "Предмет";
            var printItems = StudentsEntities.GetContext().Subjects.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexrows + 1] = item.subject;
                indexrows++;
            }
            app.Visible = true;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Add_subject_page((sender as Button).DataContext as Subjects));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {// удаление нескольких пользователей
            var usersForRemoving = DGridHotels.SelectedItems.Cast<Subjects>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} предмеов?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    StudentsEntities.GetContext().Subjects.RemoveRange(usersForRemoving);
                    StudentsEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridHotels.ItemsSource = StudentsEntities.GetContext().Subjects.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }


        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Add_subject_page(null));
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new Main_menu());
        }
    }
}
