﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Studentspr
{
    /// <summary>
    /// Логика взаимодействия для Main_menu.xaml
    /// </summary>
    public partial class Main_menu : Page
    {
        public Main_menu()
        {
            InitializeComponent();
        }

        private void liststudent_Click(object sender, RoutedEventArgs e)
        {
             manager.MainFrame.Navigate(new student_page());
        }
        private void listsubjects_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new subject_page());
        }
        private void listmarks_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new mark_page());
        }

        private void listgroups_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new group_page());
        }
        private void listspecial_Click(object sender, RoutedEventArgs e)
        {
            manager.MainFrame.Navigate(new special_page());
        }
    }
}
