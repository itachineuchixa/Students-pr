﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Studentspr
{
    /// <summary>
    /// Логика взаимодействия для mark_page.xaml
    /// </summary>
    public partial class mark_page : Page
    {
        public mark_page()
        {
            InitializeComponent();
            DGridHotels.ItemsSource = StudentsEntities.GetContext().Marks.ToList();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnExcelAll_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexrows = 1;
            worksheet.Cells[1][indexrows] = "Предмет";
            var printItems = StudentsEntities.GetContext().Subjects.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexrows + 1] = item.subject;
                indexrows++;
            }
            app.Visible = true;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
